def extra_print():
    print("Extra print from hello-world/util.py")