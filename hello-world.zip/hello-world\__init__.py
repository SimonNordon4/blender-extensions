def register():
    print("Hello World")
def unregister():
    print("Goodbye World")