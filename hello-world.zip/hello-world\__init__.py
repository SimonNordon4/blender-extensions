from . import util

def register():
    print("Hello World")
    util.extra_print()
def unregister():
    print("Goodbye World")